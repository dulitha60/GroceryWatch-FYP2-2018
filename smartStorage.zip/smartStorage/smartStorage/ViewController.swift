//
//  ViewController.swift
//  smartStorage
//
//  Created by Abdulrahman on 18/04/2018.
//  Copyright © 2018 abdoTech. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var smartStorage: UIWebView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Code to Load smartStorage webiste.
        
        let url = URL(string: "https://www.google.co.uk")
        smartStorage.loadRequest(URLRequest(url:url!))
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

