<?php
session_start();

//decalre variables

$DeviceID ="";
$productID ="";


//connect to database
$db = mysqli_connect('192.168.64.2','root','rootroot','smartStorage');


//validate product id and device id are avaliable

if(isset($_POST['validate_user'])){
       $DeviceID = mysqli_real_escape_string($db,$_POST['DeviceID']);
       $productID = mysqli_real_escape_string($db,$_POST['productID']);


		$query = "SELECT * FROM configuration WHERE DeviceID='$DeviceID' AND productID='$productID'";
		$result1 = mysqli_query($db,$query);

		if(mysqli_num_rows($result1) == 1){
			$_SESSION['DeviceID'] = $DeviceID;
			$_SESSION['success'] = "You are now logged in";
			header('location: register.php');
		}
		else{
			echo "Device Not registered";
			echo "Product Doesnt Exist";
		}
	


}