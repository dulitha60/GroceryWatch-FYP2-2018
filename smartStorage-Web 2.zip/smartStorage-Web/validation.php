<?php include('configure.php') ?>
<!DOCTYPE html>
<html>
<body>

<h2>Device and Product Validation</h2>

<form method = "post" action = "validation.php">
  Device ID:<br>
  <input type="text" name="DeviceID">
  <br>
  Product ID:<br>
  <input type="text" name="productID">

   <button type="submit" name="validate_user">Submit</button>
</form>



</body>
</html>